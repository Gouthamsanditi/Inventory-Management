<?php
session_start();
if (!isset($_SESSION['username'])) {
    $_SESSION['msg'] = "You must log in first";
    header('location: login.php');
}
if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['username']);
    unset($_SESSION['first_name']);
    unset($_SESSION['last_name']);
    header("location: index.php");
}
?>
<!DOCTYPE html>
<html>

<head>
    <title>Home</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="js/script.js"></script>
    <script src="https://kit.fontawesome.com/d8306965cb.js" crossorigin="anonymous"></script>
    <link href='https://fonts.googleapis.com/css?family=Product+Sans' rel='stylesheet' type='text/css'>
</head>

<body>
    <div class="navbar">
        <div class="title">
            <h1>Housekeeping Inventory</h1>

        </div>
        <div class="dropdown">
            <button onclick="dropdown()" class="dropbtn">
                <img class="avatar-img" src="css/avatar.png" alt="avatar">
                <?php echo $_SESSION['username'] ?>
                <i class="fas fa-chevron-circle-down"></i>
            </button>
            <div id="myDropdown" class="dropdown-content">
                <a class="dropdown-item" href="index.php?logout='1'">Log Out</a>
            </div>
        </div>
    </div>


    <div class="add-edit">
        <div class="add-item">
            <form method="POST" class="add-form" action="additem.php" autocomplete="off" enctype="multipart/form-data">
                <fieldset>
                    <legend>
                        <h2 style="text-align:center">Add Item Here</h2>
                    </legend>
                    <div class="form-group">
                        <input type="text" name="product_name" placeholder="Item name" required>
                    </div>
                    <div class="form-group">
                        <input type="number" name="price" placeholder="Price" required>
                    </div>
                    <br><br>
                    <div class="form-group">
                        <input type="number" name="quant" id="quant" min="1" max="" placeholder="Quantity" required>
                    </div>
                    <div class="form-group">
                        <button class="add" style="margin-left: 62px" onclick="document.getElementById('getFile').click()">Add Image</button>
                        <input type='file' id="getFile" style="display:none" name="image">
                    </div>
                    <br><br>
                    <button type="submit" class="addbtn form-group" name="add" style="margin-left: 220px; font-size:16px;">Add item</button>
                </fieldset>
            </form>
            <?php if (isset($_SESSION['success_message']) && !empty($_SESSION['success_message'])) { ?>
                <div class="success-message" style="margin-bottom: 20px;font-size: 16px;color: green;"><?php echo $_SESSION['success_message']; ?></div>
            <?php
                unset($_SESSION['success_message']);
            }
            ?>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="head">
                <h2 class="header-title">Items in stock</h2>
            </div>
            <div class="search">
                <form action="#" autocomplete="off">
                    <input type="text" id="myInput" onkeyup="SearchTable()" name="search" placeholder="Search..." required><i class="fas fa-search"></i>
                </form>
            </div>
            <table id="myTable">
                <thead class="text-uppercase">
                    <tr class="header">
                        <th scope="col" class="sortable" onclick="sortTable(0)">ID</th>
                        <th scope="col" class="sortable" onclick="sortTable(1)">Name</th>
                        <th scope="col" class="sortable" onclick="sortTable(2)">Price</th>
                        <th scope="col" class="sortable" onclick="sortTable(3)">Quantity</th>
                        <th scope="col">Image</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $conn = new mysqli("localhost", "root", "", "inventory");
                    $sql = "SELECT * FROM product";
                    $result = $conn->query($sql);
                    $count = 0;
                    if ($result->num_rows >  0) {
                        while ($row = $result->fetch_assoc()) {
                            $count = $count + 1;
                    ?>
                            <tr>
                                <td><?php echo $count ?></th>
                                <td><?php echo $row["product_name"] ?></th>
                                <td><?php echo $row["price"]  ?></th>
                                <td><?php echo $row["quantity"]  ?></th>
                                <td><img src="data:image/jpg;charset=utf8;base64,<?php echo base64_encode($row['images']); ?>" width='120' height='120'></td>
                                <td><a href="up"><a href="edit.php?id=<?php echo $row["product_id"] ?>"><button>Edit</button></a> <a href="up"><a href="delete.php?id=<?php echo $row["product_id"] ?>"><button>Delete</button></a></th>
                            </tr>
                    <?php }
                    } ?>
                </tbody>
            </table>
        </div>
    </div>
</body>

</html>