<?php
    $db = mysqli_connect('localhost', 'root', '', 'inventory');
    if (mysqli_connect_errno()) {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
    if (isset($_POST['submit'])) {
        $id=$_POST['id'];
        $name=mysqli_real_escape_string($db, $_POST['product_name']);
        $price=mysqli_real_escape_string($db, $_POST['price']);
        $quant=mysqli_real_escape_string($db, $_POST['quantity']);
        mysqli_query($db,"UPDATE product SET product_name='$name', price='$price' ,quantity='$quant' WHERE product_id='$id'");
        header("Location:index.php");
    }

    if (isset($_GET['id']) && is_numeric($_GET['id']) && $_GET['id'] > 0) {
        $id = $_GET['id'];
        $result = mysqli_query($db,"SELECT * FROM product WHERE product_id=".$_GET['id']);
        $row = mysqli_fetch_array($result);

        if($row) {
            $id = $row['product_id'];
            $name = $row['product_name'];
            $price = $row['price'];
            $quant=$row['quantity'];
        }
        else {
            echo "No results!";
        }
    }
?>


<!DOCTYPE HTML>
<html>
    <head>
        <title>Edit Item</title>
        <style> 
            body {
                background-image: url('css/bg-dark.jpg');
                background-repeat: no-repeat;
                background-attachment: fixed;
                background-size: cover;
                background-color: #080710;
            }          
            h4{
                font-size:36px;
                padding: 30px 10px 30px 10px;                
                margin:-8px -8px -30px -8px;
            } 
            table{
                width:30%;
                backdrop-filter: blur(16px) saturate(150%);
                -webkit-backdrop-filter: blur(16px) saturate(180%);
                background-color: rgba(255, 255, 255, .7);
                border-radius: 12px;
                border: 1px solid rgba(255, 255, 255, 0.125);
            }  
            .edit{
                font-size:15px; 
                border: none;
                padding: 9px 9px 9px 9px;
                font-weight: bold;
            }    
            .edit:hover, .edit:focus{
            background-color: rgb(168, 168, 168);
            }
            td{
                height:50px;
                font-size: 18px;
                text-align: center;
                width: 10px;
            }
        </style>    
    </head>
    <body>
        <h4 align="center"><b>Edit Records</b></h4>
        <form method="post" action="edit.php">
            <input type="hidden" name="id" value="<?php echo $id; ?>"/>
            <table align="center">
                <tr>
                    <td><b><font >Item Name<em>*</em></font></b></td>
                    <td>
                        <label>
                            <input type="text" name="product_name" value="<?php echo $name; ?>" />
                        </label>
                    </td>
                </tr><br><br>
                <tr>
                    <td><b><font color='#663300'>Price<em>*</em></font></b></td>
                    <td>
                        <label>
                            <input type="text" name="price" value="<?php echo $price ?>" />
                        </label>
                    </td>
                </tr><br><br>
                <tr>
                    <td><b><font color='#663300'>Quantity<em>*</em></font></b></td>
                    <td>
                        <label>
                            <input type="text" name="quantity" value="<?php echo $quant;?>" />
                        </label>
                    </td>
                </tr>               
            </table><br> 
            <div align="center">  
                <label>
                    <input type="submit" name="submit" value="Edit Records" class="edit">
                </label>
            </div>    
        </form>
    </body>
</html>
